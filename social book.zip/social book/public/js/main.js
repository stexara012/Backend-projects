const postForm = document.getElementById("postForm");

postForm.addEventListener("submit", async (e) => {
  e.preventDefault();

  const text = document.getElementById("postText").value;
  const image = document.getElementById("postImage").files[0];

  const formData = new FormData();
  formData.append("text", text);

  if (image) formData.append("image", image);

  const token = localStorage.getItem("token");

  const res = await fetch("/api/posts", {
    method: "POST",
    headers: {
      Authorization: token,
    },
    body: formData,
  });

  const data = await res.json();
  console.log(data);
});
