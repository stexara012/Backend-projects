const express = require("express");
const router = express.Router();
const auth = require("../middleware/auth");
const upload = require("../middleware/upload");
const Post = require("../models/Post");

// CREATE POST
router.post("/", auth, upload.single("image"), async (req, res) => {
  try {
    const { text } = req.body;

    if (!text) {
      return res.status(400).json({ msg: "Text is required" });
    }

    const newPost = new Post({
      userId: req.user,
      text,
      imageUrl: req.file ? `/uploads/${req.file.filename}` : null,
    });

    const savedPost = await newPost.save();
    res.json(savedPost);
  } catch (err) {
    console.error(err);
    res.status(500).json({ msg: "Server error" });
  }
});

module.exports = router;
