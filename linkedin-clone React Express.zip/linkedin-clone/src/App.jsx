import { BrowserRouter as Router, Routes, Route } from "react-router-dom";
import { useState, useEffect } from "react";
import axios from "axios";

import Navbar from "./components/Navbar";
import SidebarLeft from "./components/SidebarLeft";
import RightSidebar from "./components/SidebarRight";

import CreatePost from "./components/CreatePost.jsx";
import Feed from "./components/Feed.jsx";

// Stranice
function Home({ currentUser, posts, setPosts }) {
  return (
    <div className="home-content">
      {currentUser && (
        <CreatePost currentUser={currentUser} setPosts={setPosts} />
      )}
      <Feed posts={posts} currentUser={currentUser} setPosts={setPosts} />
    </div>
  );
}

function Profile() {
  return <div>Profile Page</div>;
}

export default function App() {
  const [currentUser, setCurrentUser] = useState(null);
  const [posts, setPosts] = useState([]);

  const fetchCurrentUser = async () => {
    const token = localStorage.getItem("token");
    if (!token) return;

    try {
      const res = await axios.get("http://localhost:5000/api/auth/me", {
        headers: { Authorization: `Bearer ${token}` },
      });
      setCurrentUser(res.data);
    } catch (err) {
      console.log(err);
    }
  };

  const fetchPosts = async () => {
    try {
      const res = await axios.get("http://localhost:5000/api/posts");
      setPosts(res.data);
    } catch (err) {
      console.log(err);
    }
  };

  useEffect(() => {
    fetchCurrentUser();
    fetchPosts();
  }, []);

  return (
    <Router>
      <Navbar
        currentUser={currentUser}
        onLogout={() => {
          localStorage.removeItem("token");
          setCurrentUser(null);
        }}
      />

      <div className="container" style={{ display: "flex", gap: "1rem" }}>
        <SidebarLeft />

        <div style={{ flex: 2 }}>
          <Routes>
            <Route
              path="/"
              element={
                <Home currentUser={currentUser} posts={posts} setPosts={setPosts} />
              }
            />
            <Route path="/profile" element={<Profile />} />
          </Routes>
        </div>

        <RightSidebar />
      </div>
    </Router>
  );
}