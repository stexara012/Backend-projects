import React, { useState, useEffect } from 'react';
import Modal from './Modal';
import Login from './Login';
import Register from './Register';

const Auth = () => {
  const [isLoginOpen, setLoginOpen] = useState(false);
  const [isRegisterOpen, setRegisterOpen] = useState(false);

  // Auto-popup samo ako korisnik nije logovan
  useEffect(() => {
    const token = localStorage.getItem("token");
    if (!token) setLoginOpen(true);
  }, []);

  const switchToRegister = () => {
    setLoginOpen(false);
    setRegisterOpen(true);
  };

  const switchToLogin = () => {
    setRegisterOpen(false);
    setLoginOpen(true);
  };

  return (
    <div>
      <Modal isOpen={isLoginOpen} onClose={() => setLoginOpen(false)}>
        <Login onSuccess={() => setLoginOpen(false)} />
        <div style={{ marginTop: '1rem', textAlign: 'center' }}>
          <span>If you don't have an account, </span>
          <button
            style={{
              background: 'none',
              border: 'none',
              color: '#0a66c2',
              cursor: 'pointer',
              textDecoration: 'underline'
            }}
            onClick={switchToRegister}
          >
            Register
          </button>
        </div>
      </Modal>

      <Modal isOpen={isRegisterOpen} onClose={() => setRegisterOpen(false)}>
        <Register onSuccess={() => setRegisterOpen(false)} />
        <div style={{ marginTop: '1rem', textAlign: 'center' }}>
          <span>Already have an account? </span>
          <button
            style={{
              background: 'none',
              border: 'none',
              color: '#0a66c2',
              cursor: 'pointer',
              textDecoration: 'underline'
            }}
            onClick={switchToLogin}
          >
            Login
          </button>
        </div>
      </Modal>
    </div>
  );
};

export default Auth;