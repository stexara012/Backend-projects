import { useState } from "react";
import axios from "axios";
import Comments from "./Comments.jsx";
import LikeButton from "./LikeButton.jsx";
import userImg from "../assets/images/user-1.png";
import { FaTrash, FaRegComment, FaShare } from "react-icons/fa";

function Post({ post, currentUser, onDelete }) {
  const [showComments, setShowComments] = useState(false);

  const handleDelete = async () => {
    if (!window.confirm("Are you sure you want to delete this post?")) return;

    try {
      await axios.delete(`http://localhost:5000/api/posts/${post._id}`, {
        headers: { Authorization: `Bearer ${localStorage.getItem("token")}` },
      });
      onDelete(post._id);
    } catch (err) {
      console.error(err);
      alert("Delete failed");
    }
  };

  return (
    <div className="post">
      <div className="post-author">
        <img src={post.user?.profilePic || userImg} alt="" />
        <div>
          <h1>{post.user?.name}</h1>
          <small>{post.user?.position}</small>
        </div>
      </div>

      <p>{post.content}</p>
      {post.image && <img src={post.image} width="100%" />}

      {currentUser?._id === post.user?._id && (
        <button
          onClick={handleDelete}
          style={{ background: "red", color: "white", marginTop: "5px" }}
        >
          <FaTrash /> Delete
        </button>
      )}

      <div className="post-activity">
        <LikeButton postId={post._id} userId={currentUser?._id} />
        <div onClick={() => setShowComments(!showComments)}>
          <FaRegComment /> {showComments ? "Hide" : "Comment"}
        </div>
        <div>
          <FaShare /> Share
        </div>
      </div>

      {showComments && <Comments postId={post._id} userId={currentUser?._id} />}
    </div>
  );
}

export default Post;