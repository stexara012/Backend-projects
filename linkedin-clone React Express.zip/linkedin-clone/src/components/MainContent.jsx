import CreatePost from "./CreatePost";
import Post from "./Post";
import postImg1 from "../assets/images/post-image-1.png";
import postImg2 from "../assets/images/post-image-2.png";
import postImg3 from "../assets/images/post-image-3.png";

const fakePosts = [
  {
    id: 1,
    author: "Benjamin Leo",
    position: "Founder and CEO at Gallileo Group | Angel Investor · 2h",
    text: "The Success of every Website depends on SEO and digital marketing strategy. Being on first page makes you ahead of competitors.",
    image: postImg1,
  },
  {
    id: 2,
    author: "Benjamin Leo",
    position: "Founder and CEO at Gallileo Group | Angel Investor · 2h",
    text: "The Success of every Website depends on SEO and digital marketing strategy. Being on first page makes you ahead of competitors.",
    image: postImg2,
  },
  {
    id: 3,
    author: "Benjamin Leo",
    position: "Founder and CEO at Gallileo Group | Angel Investor · 2h",
    text: "The Success of every Website depends on SEO and digital marketing strategy. Being on first page makes you ahead of competitors.",
    image: postImg3,
  },
];

function MainContent() {
  return (
    <div className="main-content">
      <CreatePost />
      {fakePosts.map((post) => (
        <Post key={post.id} {...post} />
      ))}
    </div>
  );
}

export default MainContent;