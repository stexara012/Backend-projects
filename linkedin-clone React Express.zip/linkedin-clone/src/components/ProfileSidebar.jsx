import React from "react";
import microsoftLogo from "../assets/images/microsoft.png";
import slackLogo from "../assets/images/slack.png";
import googleLogo from "../assets/images/google.png";
import stanfordLogo from "../assets/images/stanford.png";
import northLogo from "../assets/images/north.png";
import mitLogo from "../assets/images/mit.png";
import rightArrow from "../assets/images/right-arrow.png";

function ProfileSidebar() {
  return (
    <div className="profile-sidebar">
      <h2>Experience</h2>
      {[microsoftLogo, slackLogo, googleLogo].map((logo, i) => (
        <div key={i} className="profile-desc-row">
          <img src={logo} alt="" />
          <div>
            <h3>Lead Front-End Developer</h3>
            <b>Microsoft &middot; Full-Time</b>
            <b>July 2024-Present &middot; 1.5 years</b>
            <p>
              Computer programming is the process of performing a particular
              computation, usually by designing and building an executable
              computer program.
            </p>
            <hr />
          </div>
        </div>
      ))}
      <a href="#" className="experience-link">
        Show all 7 experiences. <img src={rightArrow} alt="" />
      </a>

      <h2>Education</h2>
      {[stanfordLogo, northLogo, mitLogo].map((logo, i) => (
        <div key={i} className="profile-desc-row">
          <img src={logo} alt="" />
          <div>
            <h3>Stanford University</h3>
            <b>BSEE, Electrical Engineering</b>
            <b>2018-2024</b>
            <hr />
          </div>
        </div>
      ))}

      <h2>Skills</h2>
      {["LeaderShip", "Web Development", "Python", "Javascript", "Planning", "Coding"].map((skill, i) => (
        <a key={i} href="#" className="skills-btn">{skill}</a>
      ))}

      <h2>Languages</h2>
      {["English", "German"].map((lang, i) => (
        <a key={i} href="#" className="language-btn">{lang}</a>
      ))}
    </div>
  );
}

export default ProfileSidebar;