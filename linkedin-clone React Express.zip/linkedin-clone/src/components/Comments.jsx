import { useState, useEffect } from "react";
import axios from "axios";

function Comments({ postId, userId }) {
  const [comments, setComments] = useState([]);
  const [text, setText] = useState("");

  const fetchComments = async () => {
    try {
      const res = await axios.get(`http://localhost:5000/api/comments/${postId}`);
      setComments(res.data);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchComments();
  }, [postId]);

  const handleSubmit = async (e) => {
    e.preventDefault();
    if (!text) return;

    try {
      const res = await axios.post(
        "http://localhost:5000/api/comments",
        { postId, text },
        { headers: { Authorization: `Bearer ${localStorage.getItem("token")}` } }
      );
      // Dodajemo novi komentar odmah u state
      setComments([...comments, res.data]);
      setText("");
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div style={{ marginTop: "10px" }}>
      <form onSubmit={handleSubmit}>
        <input
          type="text"
          value={text}
          placeholder="Add a comment..."
          onChange={(e) => setText(e.target.value)}
          style={{ width: "70%", marginRight: "5px" }}
        />
        <button type="submit">Comment</button>
      </form>

      <ul>
        {comments.map((c) => (
          <li key={c._id}>
            <strong>{c.user?.name || "Unknown"}: </strong>
            {c.text}
          </li>
        ))}
      </ul>
    </div>
  );
}

export default Comments;