import coverPic from "../assets/images/cover-pic.png";
import userImg from "../assets/images/user-1.png";
import itemsIcon from "../assets/images/items.png";
import premiumIcon from "../assets/images/premium.png";
import recentIcon from "../assets/images/recent.png";
import groupIcon from "../assets/images/group.png";
import hashtagIcon from "../assets/images/hashtag.png";

function SidebarLeft() {
  return (
    <div className="left-sidebar">
      <div className="sidebar-profile-box">
        <img src={coverPic} width="100%" />
        <div className="sidebar-profile-info">
          <img src={userImg} alt="" />
          <h1>Rayan Walton</h1>
          <h3>Web Developer At Microsoft</h3>
          <ul>
            <li>Your Profile views:<span>52</span></li>
            <li>Your Post Views:<span>810</span></li>
            <li>Your Connections:<span>205</span></li>
          </ul>
        </div>
        <div className="sidebar-profile-link">
          <a href="#"><img src={itemsIcon} alt="" />My Items</a>
          <a href="#"><img src={premiumIcon} alt="" />Try Premium</a>
        </div>
      </div>

      {/* RECENT */}
      <div className="sidebar-activity">
        <h3>RECENT:</h3>
        {["Web development","Online Learning","Learn Online","Code better","Group Learning","User Interface"].map((text, idx) => (
          <a key={idx} href="#"><img src={recentIcon} alt="" />{text}</a>
        ))}

        <h3>GROUPS:</h3>
        {["Web Design Group","React Developers","Frontend Masters","UI/UX Designers"].map((text, idx) => (
          <a key={idx} href="#"><img src={groupIcon} alt="" />{text}</a>
        ))}

        <h3>HASHTAG:</h3>
        {["WebDevelopment","ReactJS","UI/UX"].map((text, idx) => (
          <a key={idx} href="#"><img src={hashtagIcon} alt="" />{text}</a>
        ))}

        <div className="discover-more-link">
          <a href="#">Discover More</a>
        </div>
      </div>
    </div>
  );
}

export default SidebarLeft;