import React from "react";
import ProfileHeader from "./ProfileHeader";
import ProfileSidebar from "./ProfileSidebar";

function ProfileContent() {
  return (
    <div className="profile-main">
      <ProfileHeader />
      <div className="profile-description">
        <h2>About</h2>
        <p>
          Julius Caesar: "Veni, Vidi, Vici." - "I came, I saw, I conquered."
          Cicero: "Dum spiro, spero." - "While I breathe, I hope."
          Seneca: "Non est ad astra mollis e terris via" - "There is no easy way from the earth to the stars."
          Horace: "Carpe Diem." This famous phrase means "Seize the day."
        </p>
      </div>
      <ProfileSidebar />
    </div>
  );
}

export default ProfileContent;