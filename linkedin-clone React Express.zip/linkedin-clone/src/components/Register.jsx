import React, { useState } from 'react';
import axios from 'axios';

const API_URL = "http://localhost:5000/api";

const Register = ({ onSuccess }) => {
  const [registerData, setRegisterData] = useState({ name: '', email: '', password: '' });
  const [error, setError] = useState('');

  const handleRegister = async () => {
    try {
      const res = await axios.post(`${API_URL}/auth/register`, registerData);
      localStorage.setItem('token', res.data.token);
      onSuccess(); // zatvori modal
    } catch (err) {
      setError(err.response?.data?.message || 'Registration failed');
    }
  };

  return (
    <div>
      <h2>Register</h2>
      <input
        type="text"
        placeholder="Name"
        onChange={e => setRegisterData({ ...registerData, name: e.target.value })}
      />
      <input
        type="email"
        placeholder="Email"
        onChange={e => setRegisterData({ ...registerData, email: e.target.value })}
      />
      <input
        type="password"
        placeholder="Password"
        onChange={e => setRegisterData({ ...registerData, password: e.target.value })}
      />
      <button onClick={handleRegister}>Register</button>
      {error && <p style={{ color: 'red' }}>{error}</p>}
    </div>
  );
};

export default Register;