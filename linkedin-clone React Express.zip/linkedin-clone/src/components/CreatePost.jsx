import { useState } from "react";
import axios from "axios";
import userImg from "../assets/images/user-1.png";

function CreatePost({ currentUser, setPosts }) {
  const [content, setContent] = useState("");

  const handlePost = async () => {
    if (!content) return;
    try {
      const res = await axios.post(
        "http://localhost:5000/api/posts",
        { content },
        { headers: { Authorization: `Bearer ${localStorage.getItem("token")}` } }
      );
      setPosts(prev => [res.data, ...prev]); // odmah dodajemo post u feed
      setContent("");
    } catch (err) {
      console.error(err);
      alert("Failed to create post");
    }
  };

  return (
    <div className="create-post">
      <div className="create-post-input">
        <img src={currentUser.profilePic || userImg} alt="" />
        <textarea
          rows="2"
          placeholder="Write a post"
          value={content}
          onChange={e => setContent(e.target.value)}
        />
      </div>
      <button onClick={handlePost}>Post</button>
    </div>
  );
}

export default CreatePost;