import { useEffect, useState } from "react";
import axios from "axios";

function LikeButton({ postId, userId }) {
  const [liked, setLiked] = useState(false);
  const [count, setCount] = useState(0);

  const fetchLikes = async () => {
    try {
      const res = await axios.get(`http://localhost:5000/api/likes/${postId}`);
      setCount(res.data.count);
    } catch (err) {
      console.error(err);
    }
  };

  useEffect(() => {
    fetchLikes();
  }, [postId]);

  const toggleLike = async () => {
    try {
      const token = localStorage.getItem("token");
      await axios.post(
        "http://localhost:5000/api/likes",
        { postId, userId },
        { headers: { Authorization: `Bearer ${token}` } }
      );
      fetchLikes();
    } catch (err) {
      console.error(err);
    }
  };

  return (
    <div>
      <button onClick={toggleLike}>{liked ? "Unlike" : "Like"}</button>
      <span>{count} likes</span>
    </div>
  );
}

export default LikeButton;