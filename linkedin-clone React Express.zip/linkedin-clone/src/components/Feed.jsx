import Post from "./Post.jsx";

function Feed({ posts, currentUser, setPosts }) {
  const handleDelete = (postId) => {
    setPosts(prev => prev.filter(p => p._id !== postId));
  };

  return (
    <div className="feed">
      {posts?.length > 0 ? (
        posts.map((p) => (
          <Post
            key={p._id}
            post={p}
            currentUser={currentUser}
            onDelete={handleDelete}
          />
        ))
      ) : (
        <p>No posts yet.</p>
      )}
    </div>
  );
}

export default Feed;