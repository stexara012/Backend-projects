function ProfileMenu() {
  return (
    <div className="profile-menu-wrap" id="profileMenu">
      <div className="profile-menu">
        <div className="user-info">
          <img src="images/user-1.png" alt="" />
          <div>
            <h3>Rayan Walton</h3>
            <a href="#">See your Profile</a>
          </div>
        </div>
        <hr />
        <a href="#" className="profile-menu-link">
          <img src="images/feedback.png" alt="" />
          <p>Give Feedback</p>
          <span>&gt;</span>
        </a>
        <a href="#" className="profile-menu-link">
          <img src="images/setting.png" alt="" />
          <p>Settings & Privacy</p>
          <span>&gt;</span>
        </a>
        <a href="#" className="profile-menu-link">
          <img src="images/help.png" alt="" />
          <p>Help and Support</p>
          <span>&gt;</span>
        </a>
        <a href="#" className="profile-menu-link">
          <img src="images/display.png" alt="" />
          <p>Display</p>
          <span>&gt;</span>
        </a>
        <a href="#" className="profile-menu-link">
          <img src="images/logout.png" alt="" />
          <p>Logout</p>
          <span>&gt;</span>
        </a>
      </div>
    </div>
  );
}

export default ProfileMenu;