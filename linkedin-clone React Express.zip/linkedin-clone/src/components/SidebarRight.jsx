import moreIcon from "../assets/images/more.png";
import userImg from "../assets/images/user-1.png";
import miLogo from "../assets/images/mi-logo.png";

function SidebarRight() {
  return (
    <div className="right-sidebar">
      {/* Trending News */}
      <div className="sidebar-news">
        <img src={moreIcon} className="info-icon" />
        <h1>Trending News</h1>
        {[
          "Global Temperature record, climate changes makes heatwaves more extreme",
          "The Lost meaning of Nasca Lines.",
          "The Solar Flare: The sun on 16-th July erupted a strong solar flare.",
          "Where To Go on Vacation: Top 10 Destinations."
        ].map((text, idx) => (
          <div key={idx}>
            <a href="#">{text}</a>
            <span><br />1d ago · 1500 views</span>
            <br />
          </div>
        ))}
        <a href="#">Read More</a>
      </div>

      {/* Sidebar Ad */}
      <div className="sidebar-ad">
        <small>AD</small><br />
        <p>Master 5 Principles of Web Design:</p>
        <div>
          <img src={userImg} alt="" />
          <img src={miLogo} alt="" />
        </div>
        <b>Brand And Demand in Xiaomi</b><br /><br />
        <a href="#" className="ad-link">Learn More</a>
      </div>

      {/* Useful Links */}
      <div className="sidebar-useful-links">
        {["About","Access","Help Center","Privacy","Advertising","Get the App"].map((text, idx) => (
          <a key={idx} href="#">{text}&middot;</a>
        ))}
        <br />
        <a href="#">More</a>
        <div className="copyright-message">
          <img src="../assets/images/logo.png" alt="" />
          <br /><p>#All Rights Reserved Llknld 2024</p>
        </div>
      </div>
    </div>
  );
}

export default SidebarRight;