import React, { useState } from 'react';
import axios from 'axios';

const API_URL = "http://localhost:5000/api";

const Login = ({ onSuccess }) => {
  const [loginData, setLoginData] = useState({ email: '', password: '' });
  const [error, setError] = useState('');

  const handleLogin = async () => {
    try {
      const res = await axios.post(`${API_URL}/auth/login`, loginData);
      localStorage.setItem('token', res.data.token);
      onSuccess(); // zatvori modal
    } catch (err) {
      setError(err.response?.data?.message || 'Login failed');
    }
    const userRes = await axios.get("http://localhost:5000/api/auth/me", {
  headers: {
    Authorization: `Bearer ${res.data.token}`,
  },
});

setCurrentUser(userRes.data);
  };
  

  return (
    <div>
      <h2>Login</h2>
      <input
        type="email"
        placeholder="Email"
        onChange={e => setLoginData({ ...loginData, email: e.target.value })}
      />
      <input
        type="password"
        placeholder="Password"
        onChange={e => setLoginData({ ...loginData, password: e.target.value })}
      />
      <button onClick={handleLogin}>Login</button>
      {error && <p style={{ color: 'red' }}>{error}</p>}
    </div>
  );
};

export default Login;