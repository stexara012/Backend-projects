import React from "react";
import userImg from "../assets/images/user-1.png";
import coverImg from "../assets/images/cover-pic.png";
import connectIcon from "../assets/images/connect.png";
import chatIcon from "../assets/images/chat.png";

function ProfileHeader() {
  return (
    <div className="profile-container">
      <img src={coverImg} alt="Cover" width="100%" />
      <div className="profile-container-inner">
        <img src={userImg} alt="Profile" className="profile-pic" />
        <h1>Rayan Walton</h1>
        <b>Web Developer at Microsoft</b>
        <p>
          San Francisco, United States &middot; <a href="#">Contact info</a>
        </p>
        <div className="mutual-connection">
          <img src={userImg} alt="Mutual" />
          <span>1 mutual connection: Oliver Mike</span>
        </div>
        <div className="profile-btn">
          <a href="#">
            <img src={connectIcon} alt="" /> Connect
          </a>
          <a href="#">
            <img src={chatIcon} alt="" /> Message
          </a>
        </div>
      </div>
    </div>
  );
}

export default ProfileHeader;