import { useState } from "react";
import { Link } from "react-router-dom";
import logo from "../assets/images/logo.png";
import searchIcon from "../assets/images/search.png";
import homeIcon from "../assets/images/home.png";
import networkIcon from "../assets/images/network.png";
import jobsIcon from "../assets/images/jobs.png";
import messageIcon from "../assets/images/message.png";
import notificationIcon from "../assets/images/notification.png";
import userImg from "../assets/images/user-1.png";

export default function Navbar() {
  const [menuOpen, setMenuOpen] = useState(false);
  const toggleMenu = () => setMenuOpen(!menuOpen);

  return (
    <nav className="navbar">
      {/* LEFT */}
      <div className="navbar-left">
        <Link to="/" className="logo">
          <img src={logo} alt="Logo" />
        </Link>
        <div className="search-box">
          <img src={searchIcon} alt="Search" />
          <input type="text" placeholder="Search" />
        </div>
      </div>

      {/* CENTER */}
      <div className="navbar-center">
        <ul>
          <li>
            <Link to="/" className="active-link">
              <img src={homeIcon} alt="Home" />
              <span>Home</span>
            </Link>
          </li>
          <li>
            <Link to="#">
              <img src={networkIcon} alt="My Network" />
              <span>My Network</span>
            </Link>
          </li>
          <li>
            <Link to="#">
              <img src={jobsIcon} alt="Jobs" />
              <span>Jobs</span>
            </Link>
          </li>
          <li>
            <Link to="#">
              <img src={messageIcon} alt="Messaging" />
              <span>Messaging</span>
            </Link>
          </li>
          <li>
            <Link to="#">
              <img src={notificationIcon} alt="Notification" />
              <span>Notification</span>
            </Link>
          </li>
        </ul>
      </div>

      {/* RIGHT */}
      <div className="navbar-right">
        <div className="online">
          <img
            src={userImg}
            className="nav-profile-img"
            onClick={toggleMenu}
            alt="User"
          />
        </div>

        {/* Dropdown menu */}
        {menuOpen && (
          <div className="profile-menu-wrap">
            <div className="profile-menu">
              <div className="user-info">
                <img src={userImg} alt="User" />
                <div>
                  <h3>Rayan Walton</h3>
                  <Link
                    to="/profile"
                    onClick={() => setMenuOpen(false)} // zatvara dropdown
                  >
                    See your Profile
                  </Link>
                </div>
              </div>
              <hr />
              <Link to="#" className="profile-menu-link">
                Settings & Privacy
              </Link>
              <Link to="#" className="profile-menu-link">
                Help & Support
              </Link>
              <Link to="#" className="profile-menu-link">
                Logout
              </Link>
            </div>
          </div>
        )}
      </div>
    </nav>
  );
}