import React from "react";
import CreatePost from "../components/CreatePost";
import Post from "../components/Post";
import RightSidebar from "../components/SidebarRight";

import postImg1 from "../assets/images/post-image-1.png";
import postImg2 from "../assets/images/post-image-2.png";
import postImg3 from "../assets/images/post-image-3.png";

export default function Home() {
  const posts = [
    {
      id: 1,
      author: "Benjamin Leo",
      position: "Founder and CEO at Gallileo Group",
      time: "2 hours ago",
      content:
        "The Success of every Websites depends on search engine optimisation and digital marketing strategy. If you are on first page of all major search engines then you are ahead among your competitors.",
      image: postImg1,
      likes: 76,
      comments: 22,
      shares: 40,
    },
    {
      id: 2,
      author: "Benjamin Leo",
      position: "Founder and CEO at Gallileo Group",
      time: "2 hours ago",
      content:
        "The Success of every Websites depends on search engine optimisation and digital marketing strategy. If you are on first page of all major search engines then you are ahead among your competitors.",
      image: postImg2,
      likes: 76,
      comments: 22,
      shares: 40,
    },
    {
      id: 3,
      author: "Benjamin Leo",
      position: "Founder and CEO at Gallileo Group",
      time: "2 hours ago",
      content:
        "The Success of every Websites depends on search engine optimisation and digital marketing strategy. If you are on first page of all major search engines then you are ahead among your competitors.",
      image: postImg3,
      likes: 76,
      comments: 22,
      shares: 40,
    },
  ];

  return (
    <div className="container">
      <div className="main-content">
        <CreatePost />
        {posts.map((post) => (
          <Post key={post.id} {...post} />
        ))}
      </div>
      
    </div>
  );
}