import React from "react";
import RightSidebar from "../components/SidebarRight";

import coverPic from "../assets/images/cover-pic.png";
import userImg from "../assets/images/user-1.png";
import microsoft from "../assets/images/microsoft.png";
import slack from "../assets/images/slack.png";
import google from "../assets/images/google.png";
import stanford from "../assets/images/stanford.png";
import north from "../assets/images/north.png";
import mit from "../assets/images/mit.png";
import "./style.css"; // tvoj CSS fajl
export default function Profile() {
  return (
    <div className="container">
      <div className="profile-main">
        <div className="profile-container">
          <img src={coverPic} width="100%" />
          <div className="profile-container-inner">
            <img src={userImg} className="profile-pic" />
            <h1>Rayan Walton</h1>
            <b>Web Developer at Microsoft</b>
            <p>
              San Francisco, United States &middot; <a href="#">Contact info</a>
            </p>
          </div>
        </div>

        <div className="profile-description">
          <h2>About</h2>
          <p>
            Julius Caesar: "Veni, Vidi, Vici." - "I came, I saw, I conquered."
            Cicero: "Dum spiro, spero." - "While I breathe, I hope."
            Seneca: "Non est ad astra mollis e terris via" - "There is no easy way from the earth to the stars."
            Horace: "Carpe Diem." - "Seize the day."
          </p>
        </div>

        <div className="profile-sidebar">
          <h2>Experience</h2>
          {[{img:microsoft,title:"Lead Front-End Developer"},
            {img:slack,title:"Lead Front-End Developer"},
            {img:google,title:"Lead Front-End Developer"}].map((exp,i)=>(
            <div className="profile-desc-row" key={i}>
              <img src={exp.img} alt="" />
              <div>
                <h3>{exp.title}</h3>
                <b>Microsoft &middot; Full-Time</b>
                <b>July 2024-Present &middot; 1.5 years</b>
                <p>
                  Computer programming is the process of performing a particular computation, usually by designing and building an executable computer program.
                </p>
                <hr />
              </div>
            </div>
          ))}

          <h2>Education</h2>
          {[stanford,north,mit].map((edu,i)=>(
            <div className="profile-desc-row" key={i}>
              <img src={edu} alt="" />
              <div>
                <h3>Stanford University</h3>
                <b>BSEE, Electrical Engineering</b>
                <b>2018-2024</b>
                <hr/>
              </div>
            </div>
          ))}

          <h2>Skills</h2>
          {["Leadership","Web Development","Python","Javascript","Planning","Coding"].map((skill,i)=>(
            <a href="#" className="skills-btn" key={i}>{skill}</a>
          ))}

          <h2>Languages</h2>
          {["English","German"].map((lang,i)=>(
            <a href="#" className="language-btn" key={i}>{lang}</a>
          ))}
        </div>
      </div>
      
    </div>
  );
}