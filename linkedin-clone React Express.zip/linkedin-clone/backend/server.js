import express from "express";
import cors from "cors";
import mongoose from "mongoose";
import dotenv from "dotenv";
import authRoutes from "./routes/authRoutes.js";
import postRoutes from "./routes/postRoutes.js";
import likes from "./routes/likes.js";
import comments from "./routes/comments.js";




dotenv.config();
const app = express();

app.use(cors());
app.use(express.json());
app.use("/api/comments", comments);
mongoose.connect(process.env.MONGO_URI)
  .then(() => console.log("MongoDB connected"))
  .catch(err => console.error(err));

app.use("/api/auth", authRoutes);
app.use("/api/posts", postRoutes); // 🔥 OVO JE FALILO
app.use("/api/likes", likes);
app.get("/", (req, res) => res.send("Backend running"));

const PORT = process.env.PORT || 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));