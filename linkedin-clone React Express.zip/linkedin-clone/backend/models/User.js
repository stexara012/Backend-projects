import mongoose from "mongoose";

const userSchema = new mongoose.Schema({
  name: { type: String, required: true },
  email: { type: String, required: true, unique: true },
  password: { type: String, required: true },
  position: { type: String, default: "" }, // opcionalno, za prikaz u feed-u
  profilePic: { type: String, default: "" },
  coverPic: { type: String, default: "" }
}, { timestamps: true });

export default mongoose.model("User", userSchema);