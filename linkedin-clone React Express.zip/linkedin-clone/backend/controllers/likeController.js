import Like from "../models/Like.js";

export const getLikes = async (req, res) => {
  try {
    const count = await Like.countDocuments({ post: req.params.postId });
    res.json({ count });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

export const toggleLike = async (req, res) => {
  const { postId, userId } = req.body;
  try {
    const existing = await Like.findOne({ post: postId, user: userId });
    if (existing) {
      await existing.remove();
      return res.json({ liked: false });
    }
    await Like.create({ post: postId, user: userId });
    res.json({ liked: true });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};