import Post from "../models/Post.js";

// GET svi postovi
export const getPosts = async (req, res) => {
  try {
    const posts = await Post.find().populate("user", "name position profilePic");
    res.json(posts);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// POST novi post
export const createPost = async (req, res) => {
  const { content, image } = req.body;
  const userId = req.userId;

  try {
    const post = await Post.create({ content, image, user: userId });
    const populated = await post.populate("user", "name position profilePic");
    res.status(201).json(populated);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// DELETE post
export const deletePost = async (req, res) => {
  const { postId } = req.params;
  const userId = req.userId;

  try {
    const post = await Post.findById(postId);
   
    if (!post) return res.status(404).json({ message: "Post not found" });
    if (post.user.toString() !== req.userId)
    return res.status(403).json({ message: "Not authorized" });

    await Post.deleteOne({ _id: postId }); // ovo radi na običnom objektu
    res.json({ message: "Post deleted" });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};