import Comment from "../models/Comment.js";

// GET all comments for a post
export const getComments = async (req, res) => {
  const { postId } = req.params;
  try {
    const comments = await Comment.find({ post: postId }).populate("user", "name profilePic");
    res.json(comments);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

// POST a new comment
export const addComment = async (req, res) => {
  const { postId, text } = req.body;
  const userId = req.userId; // iz authenticate middleware

  try {
    const comment = await Comment.create({ post: postId, user: userId, text });
    const populated = await comment.populate("user", "name profilePic");
    res.status(201).json(populated);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};