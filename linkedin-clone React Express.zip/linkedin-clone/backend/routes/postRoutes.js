import express from "express";
import { authenticate } from "../middleware/authMiddleware.js";
import { getPosts, createPost, deletePost } from "../controllers/postController.js";

const router = express.Router();

// GET svi postovi
router.get("/", getPosts);

// POST novi post
router.post("/", authenticate, createPost);

// DELETE post
router.delete("/:postId", authenticate, deletePost);

export default router;