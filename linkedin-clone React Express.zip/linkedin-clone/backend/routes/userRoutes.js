const express = require("express");
const router = express.Router();

// GET current user
router.get("/me", (req, res) => {
  res.json({ _id: "123", name: "Test User" });
});

module.exports = router;