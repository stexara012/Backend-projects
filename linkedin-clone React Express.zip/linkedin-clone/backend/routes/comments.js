import express from "express";
import { getComments, addComment } from "../controllers/commentController.js";
import { authenticate } from "../middleware/authMiddleware.js";

const router = express.Router();

// Get all comments for a post
router.get("/:postId", getComments);

// Add a comment
router.post("/", authenticate, addComment);

export default router;