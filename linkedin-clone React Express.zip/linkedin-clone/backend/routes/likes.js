import express from "express";
import { authenticate } from "../middleware/authMiddleware.js";
import { getLikes, toggleLike } from "../controllers/likeController.js";

const router = express.Router();

// GET broj lajkova za post
router.get("/:postId", getLikes);

// POST / toggle like
router.post("/", authenticate, toggleLike);

export default router;