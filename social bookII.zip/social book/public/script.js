const API_URL = "http://localhost:5000/api/auth";

const authModal = document.getElementById("authModal");
const loginForm = document.getElementById("loginForm");
const registerForm = document.getElementById("registerForm");
const authTitle = document.getElementById("authTitle");

const showRegister = document.getElementById("showRegister");
const showLogin = document.getElementById("showLogin");

const loginBtn = document.getElementById("loginBtn");
const registerBtn = document.getElementById("registerBtn");

const navUser = document.getElementById("navUser");
localStorage.setItem("user", JSON.stringify(data.user));

// SWITCH FORMS
showRegister.addEventListener("click", (e) => {
  e.preventDefault();
  loginForm.style.display = "none";
  registerForm.style.display = "block";
  authTitle.innerText = "Register";
});

showLogin.addEventListener("click", (e) => {
  e.preventDefault();
  loginForm.style.display = "block";
  registerForm.style.display = "none";
  authTitle.innerText = "Login";
});

// LOGIN
loginBtn.addEventListener("click", async () => {
  const email = document.getElementById("loginEmail").value;
  const password = document.getElementById("loginPassword").value;

  const res = await fetch(`${API_URL}/login`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ email, password })
  });

  const data = await res.json();
  console.log(data);

  if (res.ok) {
    localStorage.setItem("token", data.token);
    localStorage.setItem("user", JSON.stringify(data.user));

    authModal.style.display = "none";
    document.body.classList.remove("modal-open");
  } else {
    alert(data.msg);
  }
});

// REGISTER
registerBtn.addEventListener("click", async () => {
  const name = document.getElementById("registerName").value;
  const email = document.getElementById("registerEmail").value;
  const password = document.getElementById("registerPassword").value;

  const res = await fetch(`${API_URL}/register`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ name, email, password })
  });

  const data = await res.json();
  console.log(data);

  if (res.ok) {
    alert("Registered successfully!");
    showLogin.click();
  } else {
    alert(data.msg);
  }
});

// SHOW MODAL ON LOAD
window.addEventListener("load", () => {
  const token = localStorage.getItem("token");

  if (!token) {
    authModal.style.display = "flex";
    document.body.classList.add("modal-open");
  } else {
    authModal.style.display = "none";
    document.body.classList.remove("modal-open");
  }
});
const testRegisterBtn = document.getElementById("testRegisterBtn");
const testLoginBtn = document.getElementById("testLoginBtn");

testRegisterBtn.addEventListener("click", async () => {
  const res = await fetch("http://localhost:5000/api/auth/register", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      name: "Test User",
      email: "testuser@example.com",
      password: "123456"
    })
  });

  const data = await res.json();
  console.log("REGISTER RESPONSE:", data);
});


testLoginBtn.addEventListener("click", async () => {
  const res = await fetch("http://localhost:5000/api/auth/login", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      email: "testuser@example.com",
      password: "123456"
    })
  });

  const data = await res.json();
  console.log("LOGIN RESPONSE:", data);

  if (res.ok) {
    localStorage.setItem("token", data.token);
    localStorage.setItem("user", JSON.stringify(data.user));
    alert("Test login successful!");
  }
});

postForm.addEventListener("submit", async (e) => {
  e.preventDefault();

  const text = document.getElementById("postText").value;
  const image = document.getElementById("postImage").files[0];

  const formData = new FormData();
  formData.append("text", text);
  formData.append("image", image);

  const token = localStorage.getItem("token");

  const res = await fetch("http://localhost:5000/api/posts", {
    method: "POST",
    headers: {
      Authorization: token
    },
    body: formData
  });

  const data = await res.json();
  console.log(data);

  if (res.ok) {
    alert("Post created!");
    window.location.reload();
  } else {
    alert(data.msg);
  }
});

  const data = await res.json();
  console.log("LOGIN RESPONSE:", data);

