const postForm = document.getElementById("postForm");
const postsContainer = document.querySelector(".main-content");

const token = localStorage.getItem("token");
const user = JSON.parse(localStorage.getItem("user"));

// ---------------- CREATE POST ----------------
postForm.addEventListener("submit", async (e) => {
  e.preventDefault();

  const text = document.getElementById("postText").value.trim();
  const image = document.getElementById("postImage").files[0];
  if (!text && !image) return alert("Enter text or image!");

  const formData = new FormData();
  formData.append("text", text);
  if (image) formData.append("image", image);

  const res = await fetch("/api/posts", {
    method: "POST",
    headers: { Authorization: `Bearer ${token}` },
    body: formData
  });

  if (res.ok) {
    postForm.reset();
    loadPosts();
  } else {
    const data = await res.json();
    alert(data.msg);
  }
});

// ---------------- LOAD POSTS ----------------
async function loadPosts() {
  const res = await fetch("/api/posts", {
    headers: { Authorization: `Bearer ${token}` }
  });
  const posts = await res.json();

  // ukloni stare postove
  document.querySelectorAll(".post-container").forEach(p => p.remove());

  posts.forEach(post => {
    const isAuthor = post.user._id === user.id;

    const div = document.createElement("div");
    div.classList.add("post-container");
    div.dataset.id = post._id;

    div.innerHTML = `
      <div class="post-row">
        <div class="user-profile">
          <img src="images/profile-pic.png">
          <div>
            <p>${post.user.name}</p>
            <span>${new Date(post.createdAt).toLocaleString()}</span>
          </div>
        </div>
        ${isAuthor ? `<button class="delete-btn">Delete</button>` : ""}
      </div>

      <p class="post-text">${post.text}</p>
      ${post.image ? `<img src="/uploads/${post.image}" class="post-img">` : ""}

      <div class="post-row">
        <div class="activity-icons">
          <div class="like-btn">
            <img src="images/like.png" class="like-icon">
            <span class="like-count">${post.likes.length}</span>
          </div>
          <div><img src="images/comments.png">${post.comments ? post.comments.length : 0}</div>
          <div><img src="images/share.png">0</div>
        </div>
      </div>

      <div class="comment-section" data-id="${post._id}">
        <div class="comments-list"></div>
        <input type="text" class="comment-input" placeholder="Write a comment...">
        <button class="comment-btn">Comment</button>
      </div>
    `;

    postsContainer.appendChild(div);
    loadComments(post._id);
  });
}

// ---------------- LOAD COMMENTS ----------------
async function loadComments(postId) {
  const res = await fetch(`/api/comments/${postId}`, {
    headers: { Authorization: `Bearer ${token}` }
  });
  const comments = await res.json();

  const container = document.querySelector(`.comment-section[data-id="${postId}"] .comments-list`);
  if (!container) return;

  container.innerHTML = "";
  comments.forEach(c => {
    container.innerHTML += `<div class="comment"><b>${c.user.name}</b>: ${c.text}</div>`;
  });

  // update comment count
  const postContainer = document.querySelector(`.post-container[data-id="${postId}"]`);
  const commentsIcon = postContainer.querySelector(".activity-icons div:nth-child(2)");
  commentsIcon.innerHTML = `<img src="images/comments.png">${comments.length}`;
}

// ---------------- EVENT DELEGATION ----------------
postsContainer.addEventListener("click", async (e) => {
  const postDiv = e.target.closest(".post-container");
  if (!postDiv) return;
  const postId = postDiv.dataset.id;

  // LIKE
  if (e.target.closest(".like-btn")) {
    const likeBtn = e.target.closest(".like-btn");
    const likeCountEl = likeBtn.querySelector(".like-count");
    const liked = likeBtn.classList.contains("liked");
    let count = parseInt(likeCountEl.textContent);

    await fetch(`/api/posts/like/${postId}`, {
      method: "PUT",
      headers: { Authorization: `Bearer ${token}` }
    });

    // toggle locally
    if (!liked) {
      likeBtn.classList.add("liked");
      likeBtn.querySelector(".like-icon").style.filter = "invert(41%) sepia(98%) saturate(747%) hue-rotate(202deg)";
      likeCountEl.textContent = count + 1;
    } else {
      likeBtn.classList.remove("liked");
      likeBtn.querySelector(".like-icon").style.filter = "none";
      likeCountEl.textContent = count - 1;
    }
    return;
  }

  // DELETE POST
  if (e.target.closest(".delete-btn")) {
    try {
      const res = await fetch(`/api/posts/${postId}`, {
        method: "DELETE",
        headers: { Authorization: `Bearer ${token}` }
      });
      const data = await res.json();
      if (res.ok) postDiv.remove();
      else alert(data.msg || "Nešto nije u redu pri brisanju posta.");
    } catch (err) {
      console.error(err);
      alert("Server error - provjeri konzolu");
    }
    return;
  }

  // ADD COMMENT
  if (e.target.closest(".comment-btn")) {
    const commentSection = e.target.closest(".comment-section");
    const input = commentSection.querySelector(".comment-input");
    const text = input.value.trim();
    if (!text) return;

    await fetch(`/api/comments/${postId}`, {
      method: "POST",
      headers: { "Content-Type": "application/json", Authorization: `Bearer ${token}` },
      body: JSON.stringify({ text })
    });

    input.value = "";
    loadComments(postId);
    return;
  }
});

// ---------------- INITIAL LOAD ----------------
loadPosts();
