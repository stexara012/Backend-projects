const express = require("express");
const router = express.Router();
const auth = require("../middleware/auth");
const Post = require("../models/Post");

// --- GET COMMENTS ---
router.get("/:postId", auth, async (req, res) => {
  try {
    const post = await Post.findById(req.params.postId).populate("comments.user", "name profilePic");
    if (!post) return res.status(404).json({ msg: "Post not found" });
    res.json(post.comments);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: "Server error" });
  }
});

// --- ADD COMMENT ---
router.post("/:postId", auth, async (req, res) => {
  try {
    const post = await Post.findById(req.params.postId);
    if (!post) return res.status(404).json({ msg: "Post not found" });

    const newComment = { user: req.user.id, text: req.body.text };
    post.comments.push(newComment);
    await post.save();

    res.json(post.comments);
  } catch (err) {
    console.error(err.message);
    res.status(500).json({ msg: "Server error" });
  }
});

module.exports = router;
