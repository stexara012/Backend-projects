const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const path = require('path');

const app = express();
app.use(express.json());
app.use(cors());
app.use(express.static(path.join(__dirname, 'public')));

const JWT_SECRET = 'supersecret';

// --- MongoDB connection ---
mongoose.connect('mongodb://127.0.0.1:27017/staybnb', {
}).then(() => console.log('MongoDB connected'))
  .catch(err => console.error(err));

// --- Models ---
const userSchema = new mongoose.Schema({
    name: String,
    email: String,
    password: String
});
const User = mongoose.model('User', userSchema);

const houseSchema = new mongoose.Schema({
    name: String,
    location: String,
    price: Number,
    images: [String],
    guests: Number,
    beds: Number,
    baths: Number
});
const House = mongoose.model('House', houseSchema);

// --- Auth Routes ---
app.post('/api/auth/register', async (req,res) => {
    const { name, email, password } = req.body;
    const user = new User({ name, email, password });
    await user.save();
    const token = jwt.sign({ id: user._id }, JWT_SECRET, { expiresIn: '1d' });
    res.json({ token });
});

app.post('/api/auth/login', async (req,res) => {
    const { email, password } = req.body;
    const user = await User.findOne({ email, password });
    if(!user) return res.status(400).json({ msg: 'Invalid credentials' });
    const token = jwt.sign({ id: user._id }, JWT_SECRET, { expiresIn: '1d' });
    res.json({ token });
});

// --- House Routes ---
// Search by location
app.get('/api/houses', async (req,res) => {
    const { location } = req.query;
    const houses = await House.find({ location: new RegExp(location, 'i') });
    res.json(houses);
});


// Get house by id
app.get('/api/houses/:id', async (req,res) => {
    const house = await House.findById(req.params.id);
    if(!house) return res.status(404).json({ msg: 'House not found' });
    res.json(house);
});

// --- Serve landing page ---
app.get('/', (req,res) => {
    res.sendFile(path.join(__dirname,'public','staybnb.html'));
});

const PORT = 5000;
app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
