const express = require('express');
const router = express.Router();
const House = require('../models/House');

// GET all houses (optionally filter by location)
router.get('/', async (req,res) => {
    const { location } = req.query;
    try {
        let houses;
        if(location){
            houses = await House.find({ location: { $regex: location, $options: 'i' } });
        } else {
            houses = await House.find();
        }
        res.json(houses);
    } catch(err){
        console.error(err);
        res.status(500).send('Server error');
    }
});

module.exports = router;
